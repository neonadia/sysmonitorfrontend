from operator import ne
import socket
import time
from contextlib import closing
import platform
import os
import psutil
from pymongo import MongoClient
import datetime
import socket
from psutil._common import bytes2human
from subprocess import Popen,PIPE
import subprocess
import math
import xml.etree.ElementTree as ET
import sys
import json
import cv2
import numpy as np
import gridfs

af_map = {
    socket.AF_INET: 'IPv4',
    socket.AF_INET6: 'IPv6',
    psutil.AF_LINK: 'MAC',
}

duplex_map = {
    psutil.NIC_DUPLEX_FULL: "full",
    psutil.NIC_DUPLEX_HALF: "half",
    psutil.NIC_DUPLEX_UNKNOWN: "?",
}

port = 8888
pwd = 'test'
host = sys.argv[1]
need_for_speed_mac = {}
bmc_ip = ""

def get_users():
    user_dict = {}
    user_list = []
    for one_user in psutil.users():
        if one_user[0] not in user_dict:
            user_dict[one_user[0]] = 1
        else:
            user_dict[one_user[0]] += 1
    for k in user_dict:
        user_list.append(k + ': ' + str(user_dict[k])) # ["root: 3", "test: 1" ...]
    if len(user_list) == 0:
        user_list = ['No user logged in']
    return user_list
    
def get_dmesg():
    comm = Popen('dmesg -T',shell=True,stdout=PIPE,stderr=PIPE)
    stdout,stderr = comm.communicate()
    if stderr.decode() == "":
        dmesg = stdout.decode().split('\n')
        dmesg.pop()
        return dmesg
    else:
        return False

def execute_bash_command(bash_com):
    command = Popen(bash_com,shell=True,stdout=PIPE,stderr=PIPE)
    stdout,stderr = command.communicate()
    return stdout.decode(),stderr.decode()

def check_for_gpu():
    try:
        subprocess.check_output('nvidia-smi')
        print('Nvidia GPU detected!',flush=True)
        gpu_in_sys = "NVIDIA"
        return gpu_in_sys
    except Exception: # this command not being found can raise quite a few different errors depending on the configuration
        print('No NVIDIA GPU, checking for AMD...')
        com = Popen('rocm-smi',shell=True,stdout=PIPE,stderr=PIPE)
        stdout,stderr = com.communicate()
        if 'ROCm' in stdout.decode():
            gpu_in_sys = "AMD"
            print('AMD GPU detected!')
            return gpu_in_sys
        else:
            print('No GPU detected...',flush=True)
            return 'No GPU'

def get_bmc_ip(mongoport):
    hostname = socket.gethostname()
    stdout,stderr = execute_bash_command('ipmitool lan print')
    bmc_dict = {"Hostname":hostname,'BMC':{}}
    if stderr == "":
        for i in stdout.split('\n'):
            if i.split(':')[0].strip() == 'IP Address':
                bmc_ip = i.split(":")[1].strip()
                bmc_dict["BMC"]["IP Addr"] = bmc_ip
                bmc_dict['bmc_ip'] = bmc_ip
            elif i.split(':')[0].strip() == 'MAC Address':
                mac_addr = i[i.find(':') + 1:]
                bmc_dict["BMC"]["MAC Addr"] = mac_addr
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
            collection.insert_one(bmc_dict)
            print("Inserting BMC information...",flush=True)
        else:
            print("Updating BMC information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":bmc_dict})
        client.close()
    else:
        print("ERROR: Could not run IPMITOOL",flush=True)

def get_gpu_info(mongoport):
    gpu_in_system = check_for_gpu()
    if gpu_in_system == "NVIDIA":
        stdout,stderr = execute_bash_command('nvidia-smi -q')
        if stderr == "":
            print("Parsing for NVIDIA gpu hw info.....",flush=True)
            # read the driver version
            mac_addr = socket.gethostname()
            gpu_dict = {'Hostname':mac_addr,'Graphics':{"Number of GPUs" : 0,"Manufacturer":"Nvidia", "Driver Version":"N/A","GPU":{}}}           
            lines = stdout.split('\n')
            current_device = 0
            for iter,line in enumerate(lines):
                if "Driver Version" in line:
                    driver_version = line.split(':')[1].strip()
                    gpu_dict["Graphics"]["Driver Version"] = driver_version
                elif "Product Name" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)] = {}
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["Device"] = current_device
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["Model"] = line.split(":")[1].strip()
                elif "Serial Number" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["Serial No."] = line.split(":")[1].strip()
                elif "GPU UUID" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["GPU Id"] = line.split(":")[1].strip()
                elif "VBIOS Version" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["VBIOS"] = line.split(":")[1].strip()
                elif "GPU Part Number" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["SKU."] = line.split(":")[1].strip()
                elif "Bus Id" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]["PCI Bus"] = line.split(":")[1].strip() + ":" + line.split(":")[2].strip() + ":" + line.split(":")[3].strip()
                elif "Max Power Limit" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]['Max Power(W)'] = line.split(":")[1].strip()
                elif "Architecture" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]['Series'] = line.split(":")[1].strip()
                elif "Max Clocks" in line:
                    gpu_dict["Graphics"]["GPU"][str(current_device)]['SClock'] = lines[iter+1].split(":")[1].strip()
                    gpu_dict["Graphics"]["GPU"][str(current_device)]['Mem Clock'] = lines[iter+3].split(":")[1].strip()
                    gpu_dict["Graphics"]["GPU"][str(current_device)]['Vendor'] = "Nvidia"
                    current_device = current_device + 1
                    gpu_dict["Graphics"]["Number of GPUs"] = current_device
            client = MongoClient(host, mongoport)
            db_names = client.redfish
            collection = db_names.hw_data
            if collection.count_documents({ 'Hostname': mac_addr }, limit = 1) == 0:
                collection.insert_one(gpu_dict)
                print("Inserting gpu information...",flush=True)
            else:
                print("Updating gpu information...",flush=True)
                collection.update_one({"Hostname": mac_addr},{"$set":gpu_dict})
            client.close() 
        else:
            print("ERROR running nvidia-smi: " + stderr,flush=True)    
    elif gpu_in_system == "AMD":
        file = '/root/LCM_metrics/gpu_info_' + socket.gethostname() + '.csv'
        stdout,stderr = execute_bash_command('rocm-smi -a --csv > ' + file)
        if stderr == "":
            if os.path.getsize(file) != 0: 
                df_gpu_all = []
                # read the driver version
                with open(file,"r") as cur_file:            
                    lines = cur_file.readlines()
                    columns = {}
                    card_counter = 0
                    csv_lines = []
                    for i, line in enumerate(lines):
                        if i == 1:
                            driver_version = line.split(',')[1].replace('\n','')
                            gpu_dict = {'Graphics':{"Number of GPUs" : 0,"Manufacturer":"AMD", "Driver Version":driver_version,"GPU":{}}}
                        elif i > 2:
                            if "device" in line:
                                headers = line.split(",")
                                for iter in range(len(headers)):
                                    if 'device'in headers[iter]:
                                        columns.update({'Device':iter})
                                    elif 'GPU ID' in headers[iter]:
                                        columns.update({"GPU ID":iter})
                                    elif 'VBIOS' in headers[iter]:
                                        columns.update({"VBIOS":iter})
                                    elif 'Max Graphics Package Power (W)' in headers[iter]:
                                        columns.update({"Max Power(W)":iter})
                                    elif 'GPU memory vendor' in headers[iter]:
                                        columns.update({"Memory Vendor":iter})
                                    elif 'Serial Number' in headers[iter]:
                                        columns.update({'Serial No.':iter})
                                    elif 'PCI Bus' in headers[iter]:
                                        columns.update({"PCI Bus":iter})
                                    elif 'Card series' in headers[iter]:
                                        columns.update({'Series':iter})
                                    elif 'Card model' in headers[iter]:
                                        columns.update({"Model":iter})
                                    elif 'Card vendor' in headers[iter]:
                                        columns.update({"Vendor":iter})
                                    elif 'Card SKU' in headers[iter]:
                                        columns.update({"SKU":iter})
                                    elif "Valid sclk" in headers[iter]:
                                        columns.update({"SClock":iter})
                                    elif "Valid mclk" in headers[iter]:
                                        columns.update({"Mem Clock":iter})
                            elif 'card' in line:
                                csv_lines.append(line)
                    a = 0
                for i in csv_lines:
                    i = i.split(',')
                    device = i[int(columns['Device'])]
                    gpu_id = i[int(columns['GPU ID'])]
                    vbios = i[int(columns['VBIOS'])]
                    max_pwr = i[int(columns['Max Power(W)'])]
                    mem_vendor = i[int(columns['Memory Vendor'])]
                    serial = i[int(columns['Serial No.'])]
                    pci = i[int(columns['PCI Bus'])]
                    series = i[int(columns['Series'])]
                    model = i[int(columns['Model'])]
                    vendor = i[int(columns['Vendor'])]
                    sku = i[int(columns['SKU'])]
                    sclk = i[int(columns['SClock'])]
                    mclk = i[int(columns['Mem Clock'])]
                    gpu_dict['Graphics']['GPU'][str(a)] = {"Device":device,'GPU Id':gpu_id,'VBIOS':vbios,'Max Power(W)':max_pwr,'Serial No.':serial,'PCI Bus':pci,"Series":series,"Model":model,'Vendor':vendor,"SKU":sku,'SClock':sclk,'Mem Clock':mclk} 
                    a+=1
                gpu_dict['Graphics']['Number of GPUs'] = a
                client = MongoClient(host, mongoport)
                db_names = client.redfish
                collection = db_names.hw_data
                mac_addr = socket.gethostname()
                if collection.count_documents({ 'Hostname': mac_addr }, limit = 1) == 0:
                    collection.insert_one(gpu_dict)
                    print("Inserting AMD gpu information...",flush=True)
                else:
                    print("Updating AMD gpu information...",flush=True)
                    collection.update_one({"Hostname":mac_addr},{"$set":gpu_dict})
                client.close() 
        else:
            print("ERROR running rocm-smi: " + stderr,flush=True)

    
        
def get_system_info(mongoport):
    hostname = socket.gethostname()
    systemout,systemerr = execute_bash_command('dmidecode -t system | grep Serial -A 5 -B 4')
    chassisout,chassiserr = execute_bash_command('dmidecode -t chassis | grep Serial -A 5 -B 5')
    baseboardout,baseboarderr = execute_bash_command('dmidecode -t baseboard | grep Serial -A 5 -B 4')
    if systemerr == "" and chassiserr == "" and baseboarderr == "":
        systems_lines = systemout.split('\n')
        chassis_lines = chassisout.split('\n')
        baseboard_lines = baseboardout.split('\n')
        lines = systems_lines + chassis_lines + baseboard_lines
        current_component = ""
        baseboard_num = 0
        chassis_num = 0
        system_num = 0
        system_serial = "NA"
        system_dict = {"Hostname":hostname,"System":{}}
        chassis_dict = {"Hostname":hostname,"Chassis": {}}
        baseboard_dict = {"Hostname":hostname,"Base Board":{}}
        for i in lines:
            if "Information" in i:
                if "Base" in i:
                    current_component = i.split(" ")[0] + " " + i.split(" ")[1]
                else:
                    current_component = i.split(" ")[0]
                if current_component == "System":
                    system_num += 1
                    system_dict['System'][str(system_num)] = {"Manufacturer":"N/A","Product Name":"N/A","Version":"N/A","Serial Number":"N/A","UUID":"N/A","Family":"N/A","SKU Number":"N/A"}
                elif current_component == "Chassis":
                    chassis_num += 1
                    chassis_dict["Chassis"][str(chassis_num)] = {"Manufacturer":"N/A","Version":"N/A","Type":"N/A","Serial Number":"N/A","Part Number": "N/A"}
                else:
                    baseboard_num += 1
                    baseboard_dict["Base Board"][str(baseboard_num)] = {"Manufacturer":"N/A","Product Name":"N/A","Version":"N/A","Serial Number":"N/A"}
            elif "Manufacturer" in i:
                if current_component == "System":
                    system_dict[current_component][str(system_num)]['Manufacturer'] = i.split(":")[1].strip()
                elif current_component == "Chassis":
                    chassis_dict[current_component][str(chassis_num)]['Manufacturer'] = i.split(":")[1].strip()
                elif current_component == "Base Board":
                    baseboard_dict[current_component][str(baseboard_num)]['Manufacturer'] = i.split(":")[1].strip()
            elif "Product Name" in i:
                if current_component == "System":
                    system_dict[current_component][str(system_num)]['Product Name'] = i.split(":")[1].strip()
                elif current_component == "Chassis":
                    chassis_dict[current_component][str(chassis_num)]['Product Name'] = i.split(":")[1].strip()
                elif current_component == "Base Board":
                    baseboard_dict[current_component][str(baseboard_num)]['Product Name'] = i.split(":")[1].strip()
            elif "Version" in i:
                if current_component == "System":
                    system_dict[current_component][str(system_num)]['Version'] = i.split(":")[1].strip()
                elif current_component == "Chassis":
                    chassis_dict[current_component][str(chassis_num)]['Version'] = i.split(":")[1].strip()
                elif current_component == "Base Board":
                    baseboard_dict[current_component][str(baseboard_num)]['Version'] = i.split(":")[1].strip()
            elif "Serial Number" in i and i.split(":")[1].strip() != "":
                if current_component == "System":
                    sn = i.split(":")[1].strip()
                    system_serial = sn
                    system_dict[current_component][str(system_num)]['Serial Number'] = sn
                elif current_component == "Chassis":
                    chassis_dict[current_component][str(chassis_num)]['Serial Number'] = i.split(":")[1].strip()
                elif current_component == "Base Board":
                    baseboard_dict[current_component][str(baseboard_num)]['Serial Number'] = i.split(":")[1].strip()
            elif "UUID" in i:
                system_dict[current_component][str(system_num)]['UUID'] = i.split(":")[1].strip()
            elif "SKU Number" in i:
                system_dict[current_component][str(system_num)]['SKU Number'] = i.split(":")[1].strip()
            elif "Family" in i:
                system_dict[current_component][str(system_num)]['Family'] = i.split(":")[1].strip()
            elif "Type" in i and "Wake-up" not in i:
                chassis_dict[current_component][str(system_num)]['Type'] = i.split(":")[1].strip()
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
            collection.insert_one(system_dict)
            collection.insert_one(baseboard_dict)
            collection.insert_one(chassis_dict)
            print("Inserting system information...",flush=True)
        else:
            print("Updating system information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":system_dict})
            collection.update_one({"Hostname":hostname},{"$set":chassis_dict})
            collection.update_one({"Hostname":hostname},{"$set":baseboard_dict})
        client.close()
        return system_serial
    else:
        print("Could not get system dmidecode information!",flush=True)

def get_storage_info(mongoport):
    hostname = socket.gethostname()
    stdout,stderr = execute_bash_command('nvme list --output-format=json')
    storage_dict = {"Hostname":hostname,"Storage":{}}
    if stderr == "":
        if stdout == "":
            print('No NVMe drives in systems detected',flush=True)
        else:
            nvme_data = json.loads(stdout)
            i = len(storage_dict["Storage"])
            for device in nvme_data["Devices"]:
                storage_dict["Storage"][str(i)] = device
                i += 1
            client = MongoClient(host, mongoport)
            db_names = client.redfish
            collection = db_names.hw_data
            if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
                collection.insert_one(storage_dict)
                print("Inserting nvme hardware information...",flush=True)
            else:
                print("Updating nvme hardware information...",flush=True)
                collection.update_one({"Hostname":hostname},{"$set":storage_dict})
            client.close()
    else:
        print("Could get nvme information!",flush=True)
        print("Error: " + stderr,flush=True)

    stdout,stderr = execute_bash_command('lshw')
    if stderr == "":
        hdd_data = stdout.split('\n')
        # locate the disk information
        read_flag = 0
        hdd_data_clean = []
        for line in hdd_data:
            if "*-disk" in line: # starting line
                read_flag = 1                                    
            if read_flag == 1:
                hdd_data_clean.append(line)                                    
            if "configuration:" in line: # ending line
                read_flag = 0                               
        ModelNumber = []
        DevicePath = []
        SerialNumber = []
        PhysicalSize = []
        firmware = []
        for line in hdd_data_clean:
            if "product" in line:
                ModelNumber.append(line.split(":")[1].strip())
            elif "logical name" in line:
                DevicePath.append(line.split(":")[1].strip())
            elif "serial" in line:
                SerialNumber.append(line.split(":")[1].strip())
            elif "size" in line and "GiB" in line:
                try:
                   PhysicalSize.append(int(line.split(":")[1].strip().split()[1].strip("(GB)").strip())* 1000000000)
                except IndexError:
                   print(f"Info: using different way to parse size, for {line}")
                   PhysicalSize.append(int(line.split(":")[1].strip().strip("GiB"))* 1024 * 1024 * 1024)
            elif "version" in line:
                firmware.append(line.split(":")[1].strip())
        j = len(storage_dict["Storage"])
        for i in range(len(ModelNumber)):
            storage_dict["Storage"][str(j)] = {"DevicePath":DevicePath[i],"ModelNumber" : ModelNumber[i],"Firmware": firmware[i],"SerialNumber":SerialNumber[i],"PhysicalSize":PhysicalSize[i]}
            j += 1
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
            collection.insert_one(storage_dict)
            print("Inserting hdd hardware information...",flush=True)
        else:
            print("Updating hdd hardware information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":storage_dict})
        client.close()
    else:
        print("Could not get hdd storage info",flush=True)
        print("Error: " + stderr,flush=True)

def get_nic_info(mongoport):
    stdout,stderr = execute_bash_command('lshw -class network -xml')
    if stderr == "":
        tree = ET.ElementTree(ET.fromstring(stdout))
        root = tree.getroot()
        hostname = socket.gethostname()
        net_dict = {"Hostname":hostname,"NICS":{}}
        pci_bus_nums = []
        for index,i in enumerate(root):
            if 'handle' in i.attrib: #### "handle" is attribute in the xml that denotes the PCIe bus, this excludes any virtual network connections.
                temp_dict = {'Name':"N/A","Part Number":"N/A","PCIe Bus":"N/A",'Firmware':"N/A","Vendor":"N/A","Serial":"N/A"}
                for j in i:
                    if j.tag == 'product':
                        temp_dict['Name'] = j.text
                    elif j.tag == 'businfo':
                        temp_dict["PCIe Bus"] = j.text.split("@")[1]
                        pci_bus_nums.append(j.text.split("@")[1])
                    elif j.tag == "vendor":
                        temp_dict['Vendor'] = j.text
                    elif j.tag == 'serial':
                        temp_dict['MAC'] = j.text
                    elif j.tag in 'logicalname':
                        temp_dict["Interface Name"] = j.text
                for j in i.find('configuration'):
                    if j.attrib['id'] == 'firmware':
                        temp_dict['Firmware'] = j.attrib['value'].split()[0].split(",")[0]
                net_dict["NICS"][str(index)] = temp_dict
        try:
            stdout,stderr = execute_bash_command("lspci -xxxvvv")  # read all information from lspci.
            if stderr == "":
                lines = stdout.split('\n')
                worker_bus = "" ###Bus number identifies nic card
                for x in lines:
                    if "Ethernet controller" in x or "Infiniband controller" in x:  ###If bus number read, switch worker bus to this
                        for bus_num in pci_bus_nums:
                            if bus_num.strip("000:") in x.split(" ")[0]:
                                worker_bus = bus_num
                    elif "[PN] Part number" in x: # Part number is always appear after the bus number
                        part_num = x.split(":")[1].strip()
                        for y in net_dict["NICS"]:
                            if net_dict["NICS"][str(y)]["PCIe Bus"] == worker_bus: # Cross reference bus number
                                net_dict["NICS"][str(y)]["Part Number"] = part_num
                    elif "[SN] Serial number" in x: # Serial number is always appear after the bus number
                        serial_num = x.split(":")[1].strip()
                        for y in net_dict["NICS"]:
                            if net_dict["NICS"][str(y)]["PCIe Bus"] == worker_bus: # Cross reference bus number
                                net_dict["NICS"][str(y)]["Serial"] = serial_num
        except Exception as e:
            print(e,file=sys.stderr,flush=True)
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
            collection.insert_one(net_dict)
            print("Inserting nic hardware information...",flush=True)
        else:
            print("Updating nic hardware information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":net_dict})
        client.close()
    else:
        print("Could not run lshw -class network!",flush=True)
        print("Error: " + stderr,flush=True)

def get_cpu_info(mongoport):
    cpu_dict = {"CPU":{}}
    stdout, stderr = execute_bash_command('lscpu')
    if stderr == "":
        lines = stdout.split('\n')
        lines.pop(len(lines) - 1)
        for i in lines:
            keyData = i.split(":")
            cpu_dict['CPU'][keyData[0].strip()] = keyData[1].strip()
        hostname = socket.gethostname()
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
            collection.insert_one(cpu_dict)
            print("Inserting cpu information...",flush=True)
        else:
            print("Updating cpu information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":cpu_dict})
        client.close()
    else:
        print("Could not run lscpu!",flush=True)
        print("Error: " + stderr,flush=True)
        
def get_fan_info(mongoport):
    stdout, stderr = execute_bash_command('ipmitool sdr list full | grep -i fan')
    hostname = socket.gethostname()
    if stderr == "":
        fans =  {"Hostname":hostname,"FANS" : {}}
        lines = stdout.split('\n')
        i = 0
        for line in lines:
            if "FAN" in line and "OS" not in line:
                fans["FANS"][str(i)] = {"name": line.split("|")[0].strip(),'status' :line.split("|")[2].strip(),"rpm":line.split("|")[1].strip() }
                i += 1
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
            collection.insert_one(fans)
            print("Inserting FAN information...",flush=True)
        else:
            print("Updating FAN information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":fans})
        client.close()
    else:
        print("Could not run ipmitool sdr list full | grep -i fan!",flush=True)
        print("Error: " + stderr,flush=True)

def get_psu_info(mongoport):
    stdout, stderr = execute_bash_command('dmidecode --type 39')
    hostname = socket.gethostname()
    if stdout != ""  and stderr == "":
        lines = stdout.split('\n')
        modules = 0
        serial_numbers = []
        module_numbers = []
        status = []
        manufacturer = []
        try:
            for line in lines:
                if 'Serial Number' in line:
                    serial_numbers.append(line.split(':')[1].strip())
                    modules += 1
                elif 'Part Number' in line:
                    module_numbers.append(line.split(':')[1].strip())
                elif 'Manufacturer' in line:
                    manufacturer.append(line.split(':')[1].strip())
                elif 'Status' in line:
                    status.append(line.split(':')[1].strip())
            psu_dict = {"PSU":{"Number of PSUs":modules}} 
            for i in range(modules):
                psu_dict["PSU"][str(i)] = {"Serial No.": serial_numbers[i],"Status":status[i],"Module No.":module_numbers[i],"Manufacturer" : manufacturer[i]}
        except Exception as e:
            print("Exception occured at parsing dmidecode output",flush=True)
            print(e,flush=True)
        else:
            client = MongoClient(host, mongoport)
            db_names = client.redfish
            collection = db_names.hw_data
            if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
                collection.insert_one(psu_dict)
                print("Inserting PSU information...",flush=True)
            else:
                print("Updating PSU information...",flush=True)
                collection.update_one({"Hostname":hostname},{"$set":psu_dict})
            client.close()
    else:
        print("Could not run dmidecode --type 39 for psu data",flush=True)
        print("Error: " + stderr,flush=True)

def send_topo(mongoport,system_sn):
    hostname = socket.gethostname()
    png_filename = "topo_" + system_sn + ".png"
    topo_dict = {"Hostname":hostname}
    client = MongoClient(host, mongoport)
    db_names = client.redfish
    collection = db_names.hw_data
    stdout, stderr = execute_bash_command("lstopo -f --rect --append-legend 'SN: " + system_sn + "' /root/LCM_metrics/" + png_filename) #### FIX RATIO HERE!!!!!!!
    if stderr == "":
        fs = gridfs.GridFS(db_names)
        try:
            img = cv2.imread('/root/LCM_metrics/' + png_filename)
            imageString = img.tobytes()
            imageID = fs.put(imageString, encoding='utf-8')
            meta ={
                'filename':png_filename,
                'imageID': imageID,
                'shape': img.shape,
                'dtype': str(img.dtype)
            }
            topo_dict['TOPO_file'] = meta
        except Exception as e: 
            print('Could not read image',flush=True)
            print('Error:' + e, flush=True)
        else:
            if collection.count_documents({ 'Hostname': hostname }, limit = 1) == 0:
                collection.insert_one(topo_dict)
                print("Inserting System Topography information...",flush=True)
            else:
                print("Updating System Topography information...",flush=True)
                collection.update_one({"Hostname":hostname},{"$set":topo_dict})
            client.close()
    else:
        print("Could not run lstopo!",flush=True)
        print("Error: " + stderr,flush=True)
    
def get_mem_dmidecode(mongoport):
    stdout, stderr = execute_bash_command('dmidecode -t memory')
    if stderr == "":
        lines = stdout.split('\n')######## Get Memory data (dmidecode type 17)
        serial_nums = []
        size = []
        con_mem_speed = []
        max_speed = []
        manu = []
        type = []
        pn = []
        dimm_speed = ""
        all_dimms_same_speed = True
        for line in lines:
            # Initialize for all lists, assume the sequency is that 
            if 'Memory Device' in line:
                size.append("No Module Installed")
                serial_nums.append("NO DIMM")
                con_mem_speed.append("Unknown")
                max_speed.append("Unknown")
                manu.append("NO DIMM")
                type.append("UNKNOWN")
                pn.append("NO DIMM") 
                continue
            elif 'Size:' in line and 'Volatile' not in line and 'Cache' not in line and 'Logical' not in line:                                        
                temp_size = line.split(":")[1].strip()
                if "MB" in temp_size:
                    gb_converter = math.trunc(round(int(temp_size.split(" ")[0]) / 1000,0))
                    temp_size = str(gb_converter) + " GB"
                size[-1] = temp_size
                continue
            elif 'Serial Number' in line:
                serial_nums[-1] = line.split(":")[1].strip()
                continue
            elif 'Configured Memory Speed' in line or 'Configured Clock Speed' in line:
                con_mem_speed[-1] = line.split(":")[1].strip()
                if 'Unknown' not in line.split(":")[1].strip():
                    if dimm_speed != line.split(":")[1].strip().replace("MT/s","MHz") and dimm_speed != "":
                        all_dimms_same_speed = False
                    dimm_speed = line.split(":")[1].strip().replace("MT/s","MHz")
                continue
            elif 'Speed' in line and 'Configured Memory Speed' not in line and 'Configured Clock Speed' not in line:
                max_speed[-1] = line.split(":")[1].strip()
                continue
            elif 'Manufacturer' in line and 'Module' not in line and 'Memory' not in line:
                manu[-1] = line.split(":")[1].strip()
                continue
            elif 'Part Number' in line:
                pn[-1] = line.split(":")[1].strip()
                continue
            elif 'Type' in line and 'Detail' not in line and "Error" not in line:
                type[-1] = line.split(":")[1].strip()
                continue                                        
        gb = 0
        dimms_no = 0
        for i in size:
            if i != "No Module Installed":
                dimms_no += 1
                try:
                    gb += int(i.split(" ")[0])
                except:
                    gb += 0
                    print(f'One memory slot might have issue, the "SIZE" shows "{i}"')
        total_mem = gb
        hostname = socket.gethostname()
        memory_data = {"Hostname":hostname,"Memory":{"DIMMS":str(dimms_no),"Total Memory":str(total_mem),"Slots": {}}}
        for i in range(len(size)):
            memory_data["Memory"]["Slots"]["DIMM" + str(i)] = {"Manufacturer" : manu[i],"Serial No.":serial_nums[i],"Part No.": pn[i],"Max Speed":max_speed[i],"Configured Speed": con_mem_speed[i],"Size":size[i],"Type":type[i]}
        client = MongoClient(host, mongoport)
        db_names = client.redfish
        collection = db_names.hw_data
        if collection.count_documents({ 'Hostname': hostname}, limit = 1) == 0:
            collection.insert_one(memory_data)
            print("Inserting Memory dmidecode information...",flush=True)
        else:
            print("Updating Memory dmidecode information...",flush=True)
            collection.update_one({"Hostname":hostname},{"$set":memory_data})
        client.close()
        return dimm_speed,all_dimms_same_speed
    else:
        print("Could not run dmidecode!",flush=True)
        print("Error: " + stderr,flush=True)

def get_disk_stats():
    mount_points = {}
    for i in psutil.disk_partitions():
        mount_points[i.mountpoint] = {}
        mount_points[i.mountpoint]["Percent"] = str(psutil.disk_usage(i.mountpoint).percent) + "%"
        mount_points[i.mountpoint]["Total"] = bytes2human(psutil.disk_usage(i.mountpoint).total)
        mount_points[i.mountpoint]["used"] = bytes2human(psutil.disk_usage(i.mountpoint).used)
        mount_points[i.mountpoint]["free"] = bytes2human(psutil.disk_usage(i.mountpoint).free)  
    return mount_points    

def acquire_nic_macs():
    io_counters = psutil.net_io_counters(pernic=True)
    for nic,addrs in psutil.net_if_addrs().items():
        mac_addr = 'n/a'
        for addr in addrs:
            if af_map.get(addr.family, addr.family) == "MAC" and nic in io_counters:
                io = io_counters[nic]
                mac_addr = str(addr.address)
                upload =  float(io.bytes_sent)
                download = float(io.bytes_recv)
                need_for_speed_mac[mac_addr] = {"BytesRecv" : upload, "BytesSent" : download}

def get_nic_cardInfo():
    net_cards = {}
    stats = psutil.net_if_stats()
    io_counters = psutil.net_io_counters(pernic=True)
    for nic, addrs in psutil.net_if_addrs().items():
        net_cards[nic] = {"speed": 0, "duplex":0, "mtu":0,"up":"n/a","incoming":{},"outgoing":{},"addresses":{}}
        get_speed = False
        if nic in stats:
            st = stats[nic]
            net_cards[nic]['speed'] = str(st.speed) + "MB"
            net_cards[nic]['duplex'] = str(duplex_map[st.duplex])
            net_cards[nic]['mtu'] = str(st.mtu)
            net_cards[nic]['up'] = "yes" if st.isup else "no"
        if nic in io_counters:
            io = io_counters[nic]
            net_cards[nic]['incoming']['bytes'] = bytes2human(io.bytes_recv)
            net_cards[nic]['incoming']['pkts'] = io.packets_recv
            net_cards[nic]['incoming']['errs'] = io.errin
            net_cards[nic]['incoming']['drops'] = io.dropin
            net_cards[nic]['outgoing']['bytes'] = bytes2human(io.bytes_sent)
            net_cards[nic]['outgoing']['pkts'] = io.packets_sent
            net_cards[nic]['outgoing']['errs'] = io.errout
            net_cards[nic]['outgoing']['drops'] = io.dropout
            net_cards[nic]['outgoing']['Upload Speed'] = "n/a"
            net_cards[nic]['incoming']['Download Speed'] = "n/a"

        for addr in addrs:
            if af_map.get(addr.family, addr.family) == "MAC" and nic in io_counters:
               mac_addr = str(addr.address)
               get_speed = True
            net_cards[nic]["addresses"][af_map.get(addr.family, addr.family)] = {'address':str(addr.address)}
            if addr.broadcast:
                net_cards[nic]["addresses"][af_map.get(addr.family, addr.family)]['broadcast'] = str(addr.broadcast)
            if addr.netmask:
                net_cards[nic]["addresses"][af_map.get(addr.family, addr.family)]['netmask'] = str(addr.netmask)
            if addr.ptp:
                net_cards[nic]["addresses"][af_map.get(addr.family, addr.family)]['p2p'] = str(addr.ptp)
            ###################### NIC SPEED CALCULATION #########################################
        if nic in io_counters and get_speed:
            a1 = need_for_speed_mac[mac_addr]["BytesRecv"]
            b1 = float(io.bytes_recv)
            a2 = need_for_speed_mac[mac_addr]["BytesSent"]
            b2 = float(io.bytes_sent)
            download_speed = round((((b1 - a1) / 1024 / 1024)*8),2)
            upload_speed = round((((b2 - a2) / 1024 / 1024)*8),2)
            a1 = b1
            a2 = b2
            need_for_speed_mac[mac_addr]["BytesRecv"] = a1
            need_for_speed_mac[mac_addr]["BytesSent"] = a2
            net_cards[nic]['outgoing']['Upload Speed'] = str(upload_speed) + " Mb/s"
            net_cards[nic]['incoming']['Download Speed'] = str(download_speed) + " Mb/s"        
    return(net_cards)

def socket_isopen(host,port):
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        if sock.connect_ex((host,port)) == 0:
            return True
        else:
            return False

def check_os():
    node  = platform.platform().split('-with-')
    kernel = node[0]
    os_version = node[1]
    os_release = ''
    if os.path.isfile('/etc/os-release'):
        with open('/etc/os-release', 'r') as os_env:
            for line in os_env:
                if line.startswith('NAME='):
                    os_release += line.replace('NAME=','').replace('"','').replace("'","")
                elif line.startswith('VERSION='):
                    os_release += ' ' + line.replace('VERSION=','').replace('"','').replace("'","")
    if len(os_release) > 0:
        os_version = os_release
    return os_version,kernel

def get_cpu_metrics():
    usage = round(psutil.cpu_percent(),2)
    freq = round(psutil.cpu_freq()[0],2)
    if freq > 10:
        freq = round(freq / 1000,2)
    l1, l2, l3 = psutil.getloadavg()
    avg_load = round((l3/os.cpu_count()) * 100,2)
    return usage,freq,avg_load  

def get_ips(family):
    for interface, snics in psutil.net_if_addrs().items():
        for snic in snics:
            if snic.family == family:
                yield (interface, snic.address) 

def establishMongoConnection(mongoport):
    cpu_metrics = get_cpu_metrics()
    operating_sys = check_os()
    hostname = socket.gethostname()
    user_list = get_users()
    all_datetime_start = get_datetime()
    ipv4 = list(get_ips(socket.AF_INET))
    ipv6 = list(get_ips(socket.AF_INET6))
    # create metric_dict with datetime information
    metric_dict = {"Hostname" : hostname, "OS": operating_sys[0], 'Kernel':operating_sys[1],\
    "users": user_list, "boottime": all_datetime_start[1], "uptime": all_datetime_start[2],\
    "datetime": all_datetime_start[0], "ipv4" : {}, "ipv6" : {} , "CPU_Metrics" : {}}
    for ip in ipv4:
        metric_dict['ipv4'][ip[0]] = ip[1]
    for ip in ipv6:
        metric_dict['ipv6'][ip[0]] = ip[1]
    metric_dict["CPU_Metrics"]["Usage"] = cpu_metrics[0]
    metric_dict["CPU_Metrics"]["Frequency"] = cpu_metrics[1]
    metric_dict["CPU_Metrics"]["Avg_load"] = cpu_metrics[2]
    metric_dict['dmesg'] = get_dmesg()
    dmesg_length = len(metric_dict['dmesg'])
    client = MongoClient(host, mongoport)
    db_names = client.redfish
    my_query = {"Hostname" : hostname}
    collection = db_names.metrics
    collection.delete_many(my_query)
    _id = collection.insert_one(metric_dict)
    client.close()
    time.sleep(1)
    mem_speed, all_speed = get_mem_dmidecode(mongoport)
    get_cpu_info(mongoport)
    get_nic_info(mongoport)
    get_storage_info(mongoport)
    sys_serial = get_system_info(mongoport)
    get_bmc_ip(mongoport)
    get_gpu_info(mongoport)
    get_fan_info(mongoport)
    get_psu_info(mongoport)
    send_topo(mongoport,sys_serial)
    return mem_speed, all_speed, dmesg_length

def get_ram_usage_pct():
    return psutil.virtual_memory().percent

def get_ram_total():
    return int(psutil.virtual_memory().total)

def get_ram_used():
    return int(psutil.virtual_memory().used)
def get_disk_usage_home():
    disk = str(psutil.disk_usage('/home').percent) + "%"
    return disk

def get_disk_usage_root():
    disk = str(psutil.disk_usage('/').percent) + "%"
    return disk

def get_running_processes():
    running = [(p.pid, p.info) for p in psutil.process_iter(['name', 'status']) if p.info['status'] == psutil.STATUS_RUNNING]
    running_dict = {}
    for iter,i in enumerate(running):
        running_dict[str(iter)] = {"name": i[1]['name'] , "pid": i[0]}
    return running_dict

def get_mongo_port():
    hostname = socket.gethostname()
    print("Retrieving Mongo Port....")
    con = MongoClient(host,8888)
    db = con.udp_config
    ports = db.client_config
    myquery = { "mac": hostname.replace("-","") }
    mongoport = 0
    if ports.count_documents(myquery, limit = 1) != 0:
        mydoc = ports.find(myquery)
        for i in mydoc:
            mongoport = i['resultport']
            print("Got Mongo Port! Mongoport=" + str(mongoport),flush=True)
            return mongoport
    else:
        print("Cannot find hostname in server",flush=True)
        return mongoport

# get current time, boot time and uptime.
def get_datetime():
    currenttime = datetime.datetime.now()
    boottime = datetime.datetime.fromtimestamp(psutil.boot_time())
    uptime = str(currenttime - boottime)
    if '.' in uptime:
        uptime = uptime.split('.')[0]
    return [currenttime.strftime("%Y-%m-%d %H:%M:%S"), boottime.strftime("%Y-%m-%d %H:%M:%S"), uptime]

def main():
    acquire_nic_macs()
    mongoport = 0
    dmesg_length = 0
    while not socket_isopen(host,port):
        time.sleep(10)
        print("Port Closed",flush=True)
    print("Port open!",flush=True)
    found_mongoport = False
    while not found_mongoport:
        mongoport = get_mongo_port()
        if mongoport != 0:
            found_mongoport = True
        else:
            print("Please verify the hostname for this node is in the LCM....",flush=True)
            time.sleep(10)
    mem_speed, all_speed, dmesg_length = establishMongoConnection(mongoport)
    client = MongoClient(host, mongoport)
    db_names = client.redfish
    collection = db_names.metrics
    while True:
        print("Connection established updating metrics...",flush=True)
        a1 = int(psutil.net_io_counters(pernic=False, nowrap=True).bytes_recv)
        a2 = int(psutil.net_io_counters(pernic=False, nowrap=True).bytes_sent)
        while socket_isopen(host,port):
            hostname = socket.gethostname()
            all_datetime = get_datetime()
            user_list = get_users()
            if collection.count_documents({ 'Hostname': hostname }, limit = 1) != 0:
                cpu_metrics = get_cpu_metrics()
                total_ram = '{} MB'.format(int(get_ram_total() / 1024 / 1024))
                ram_perc = '{} %'.format(get_ram_usage_pct())
                ram_used = '{} MB'.format(int(get_ram_used() / 1024 / 1024))
                metrics = {"users": user_list, "datetime": all_datetime[0], "uptime": all_datetime[2], \
                "CPU_Metrics" : {"Usage" : cpu_metrics[0] , "Frequency" : cpu_metrics[1], "Avg_load" : cpu_metrics[2]}}
                metrics["Memory"] = {"Total RAM" : total_ram , "RAM Used %" : ram_perc , "RAM Used MB" : ram_used,'Speed':mem_speed,"All dimms same speed":all_speed}
                metrics["Processes"] = get_running_processes()
                b1 = int(psutil.net_io_counters(pernic=False, nowrap=True).bytes_recv)
                b2 = int(psutil.net_io_counters(pernic=False, nowrap=True).bytes_sent)
                download_speed = str(round(((b1 - a1) / 1024 / 1024) * 8, 2)) + " Mb/s"
                upload_speed = str(round(((b2 - a2) / 1024 / 1024) * 8, 2)) + " Mb/s"
                metrics["Network"] = {"Download Speed" : download_speed, "Upload Speed" : upload_speed}
                metrics["Disk"] = get_disk_stats()
                a1 = b1
                a2 = b2
                metrics["NETCARDS"] = get_nic_cardInfo()
                dmesg = get_dmesg()
                if dmesg_length != len(dmesg):
                    dmesg_length = len(dmesg)
                    metrics['dmesg'] = dmesg
                    print("Updating dmesg...",flush=True)
                collection.update_one({"Hostname":hostname},{"$set":metrics})
            else:
                print("Detected New LCM Deployment....",flush=True)
                found_mongoport = False
                while not found_mongoport:
                    mongoport = get_mongo_port()
                    if mongoport != 0:
                        found_mongoport = True
                    else:
                        print("Please verify the hostname for this node is in the LCM....",flush=True)
                        time.sleep(10)
                mem_speed, all_speed, dmesg_length = establishMongoConnection(mongoport)
            time.sleep(1)
        print("Connection closed...",flush=True)
        while not socket_isopen(host,port):
            time.sleep(10)

if __name__ == "__main__":
    main()  
