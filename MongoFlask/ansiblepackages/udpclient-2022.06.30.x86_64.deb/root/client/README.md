# STEPS TO SET UP UDPCLIENTS: Chenyang Li 2022/03/28

### create service file
```
[Unit]
Description=My daemon

[Service]
WorkingDirectory=/root/client/
ExecStart=/root/client/udpclient-2.3.py 172.27.28.15:8888
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target

```
### Install python3.6 or higher version

### Install net-tools, ntpd
```
yum install net-tools
yum instll ntpd
```

### Create working dir 
```
mkdir client
```

### Inside folder paste udpclient-1.7.py and inputPaser.py
```
install benchmarks tools
```

### Synchronis datetime
```
ntpd -g -q
hwclock -wu
timedatectl set-timezone America/Los_Angeles
```

### Stop/disable firewall
```
systemctl stop firewalld
systemctl disable firewalld
```

### Reload daemon
```
systemctl daemon-reload
```

### Enable and Start udpclient service
```
systemctl enable udpclient.service
systemctl start udpclient.service
```

