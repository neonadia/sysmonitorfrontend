#!/bin/python3

from subprocess import Popen, PIPE
import json
import sys
import time
import re
import os
from glob import glob
    
def parseInput(filepath): 
    '''
    EXAMPLE:
    {
    "category":"benchmark",
    "exe":"stress-ng",
    "prefix":"",
    "config":"--matrix 0 -t 10s --metrics-brief --tz",
    "log":"stress-ng",
    "walltime":3600,
    "parseResultLog":1,
    "selfLog":0,
    "selfLogPath":"",
    "numOfResults":1,
    "keywords":[["real time","usr time","sys time","bogo ops/s"]],
    "addRow":[2],
    "dfs":[" "],
    "index":[-2],
    "unit":["ops/s"],
    "resultName":["Throughput"],
    "criteriaType":["numericType"],
    "criteria":[[0,99999]]
    }
    '''
    # all keys
    basicKeys = ['category','exe','prefix','config','log','walltime','parseResultLog']
    parserKeys = ['selfLog','selfLogPath','numOfResults','keywords','addRow','dfs','index','unit','resultName','criteriaType','criteria']
    # key type, note that keywords not included inside either strkeys nor intKeys
    strKeys = ['category','exe','prefix','config','log','walltime','selfLogPath','dfs','unit','resultName','criteriaType']
    listKeys = ['keywords','addRow','dfs','index','unit','resultName','criteriaType','criteria']
    intKeys = ['parseResultLog','walltime','selfLog','numOfResults','addRow','index']
    specialKeys = ['criteria']
    print('Parsing json into dict...', flush=True)    
    try:
        with open(filepath, "r") as read_file:
            inputData = json.load(read_file)
    except Exception as e:
        print("parseInput() failed", flush=True)
        print("Error msg:\n{0}".format(e), flush=True)
        raise Exception('parseInput() failed, Parse json into dict failed. Error msg:\n{0}'.format(e))
    print("Checking if need to parse log...", flush=True)
    if inputData['parseResultLog'] == 0:
        keys = basicKeys
        print("Log will not be parsed", flush=True)
    elif inputData['parseResultLog'] == 1:
        keys = basicKeys + parserKeys
        print("Log will be parsed", flush=True)
    else:
        raise Exception('parseInput() failed, parseResultLog should be either 0 or 1.')
    # check whether key exsists in the inputData
    print("Checking if all necessary keys are included in the config....", flush=True)
    for key in keys:
        if key not in inputData.keys():
            print("parseInput() failed, " + key + " not found", flush=True)
            raise Exception("parseInput() failed, " + key + " not found")
    # check key type:
    print("Checking if all necessary keys have valid format....", flush=True)
    for key in inputData.keys():
        print("Checking " + key + ":", flush=True)
        if key in intKeys and key not in listKeys:
            print("Checking listKeys....", flush=True)
            if not isinstance(inputData[key], int):
                raise Exception("parseInput() failed, the value of " + key + " must be int, the type is " + str(type(inputData[key])))
        elif key in strKeys and key not in listKeys:
            print("Checking strKeys....", flush=True)
            if not isinstance(inputData[key], str):
                raise Exception("parseInput() failed, the value of " + key + " must be str, the type is " + str(type(inputData[key])))
        elif key in listKeys:
            print("Checking listKeys....", flush=True)
            if not isinstance(inputData[key], list):
                raise Exception("parseInput() failed, the value of " + key + " must be list, the type is " + str(type(inputData[key])))
            if len(inputData[key]) != inputData['numOfResults']:
                raise Exception("parseInput() failed, the length of value of " + key + " must be same as numOfResults: " + str(inputData['numOfResults']))
            for i in inputData[key]:
                if key in intKeys and not isinstance(i, int):
                    raise Exception("parseInput() failed, the item of list of the " + key + " must be int, the type is " + str(type(i)))
                elif key in strKeys and not isinstance(i, str):
                    raise Exception("parseInput() failed, the item of list of the " + key + " must be str, the type is " + str(type(i)))
        if key in specialKeys:
            print("Checking specialKeys....", flush=True)
            if not isinstance(inputData[key], list):
                raise Exception("parseInput() failed, the value of " + key + " must be list, the type is " + str(type(inputData[key])))
            if len(inputData[key]) != inputData['numOfResults']:
                raise Exception("parseInput() failed, the length of value of " + key + " must be same as numOfResults: " + str(inputData['numOfResults']))
            for i, j in zip(inputData[key],inputData['criteriaType']):
                if len(i) != 2:
                    raise Exception("parseInput() failed, the length of lit of " + key + " must be 2!")
                if j == 'numericType':
                    for v in i:
                        if not isinstance(v, int):
                            raise Exception("parseInput() failed, the value of list of " + key + " must be int, the type is " + str(type))
                    if i[0] > i[1]:
                        raise Exception("parseInput() failed, the smaller value of list of " + key + " must be in front of larger one.")
                elif j == 'stringType':
                    for v in i:
                        if not isinstance(v, str):
                            raise Exception("parseInput() failed, the value of list of " + key + " must be str, the type is " + str(type(v)))
                else:
                    raise Exception("criteriaType should be either numericType or stringType, not " + j)
    print("parseInput() Done successfully, all inputs are valid!", flush=True)                    
    return inputData
            
    
def runBenchmark(bmName,prefix,config,walltime):
    bmST = time.ctime()
    myenv = os.environ.copy()
    myenv["TERM"] = "xterm"
    print('Starting benchmark...',flush=True)
    process = Popen(prefix + ' ' + bmName + ' ' + config, shell=True, stdout=PIPE, stderr=PIPE, env=myenv)        
    stdout, stderr = process.communicate(timeout=walltime)
    print('Benchmark Done...',flush=True)
    outStr = stdout.decode("utf-8")#.split('\n')
    errStr = stderr.decode("utf-8")#.split('\n')   
    bmET = time.ctime()
    logStr = bmName + ': info:  [START] ' + bmST + '\n'
    logStr += bmName + ': info:  [END] ' + bmET + '\n'
    if sys.getsizeof(outStr) + sys.getsizeof(errStr) >= 15000000:
        logStr += bmName + ': info:  [WARNING] OUTPUT FILE is too large to transfer!!\n'
        return logStr
    logStr += outStr + '\n'
    logStr += errStr
    return logStr

def runCommand(bmName,walltime):
    walltime = int(walltime)
    print('Running command...',flush=True)
    try:
        process = Popen(bmName, shell=True, stdout=PIPE, stderr=PIPE)        
        stdout, stderr = process.communicate(timeout=walltime)
    except Exception as e:
        logStr = str(e)
        print('====================== Error message ======================')
        print(e)
        print('===========================================================')
        return logStr
    print('Command Done...',flush=True)
    outStr = stdout.decode("utf-8")#.split('\n')
    errStr = stderr.decode("utf-8")#.split('\n')   
    logStr = ''
    if sys.getsizeof(outStr) + sys.getsizeof(errStr) >= 15000000:
        logStr += bmName + ': info:  [WARNING] OUTPUT LOG SIZE is too large to transfer!!\n'
        return logStr
    logStr += outStr + '\n'
    logStr += errStr
    return logStr

def generateOutput(logStr,outpath):
    with open(outpath, 'w') as out:
        out.write(logStr)

def removeOutput(pattern):
    for file in glob('./' + pattern):
        print('Delete ' + file, flush=True)
        os.remove(file)


def resultParser(contents, keywords, addRow, dfs, index, unit, criteriaType, criteria):
    contents = contents.split('\n')
    output = {'result':'N/A','conclusion':'N/A'}
    conclusion = 1
    rawResult = []
    resultS = ''
    for kw, ar, df, ix, un, ct, cr in zip(keywords, addRow, dfs, index, unit, criteriaType, criteria):
        line_numbers = []
        for i, content in enumerate(contents):
            if all([x in content for x in kw]):
                line_numbers.append(i+ar)
        print('Find ' + str(len(line_numbers)) + ' results!', flush=True)
        if len(line_numbers) < 1:
            return {'result':'N/A','conclusion':'N/A'}       
        print('Take the first one as the result!', flush=True)
        if df == "None":
            result = str(contents[line_numbers[0]].split()[ix])
        else:
            result = str(contents[line_numbers[0]].split(df)[ix])
        print("Current result is:", flush=True)
        print(result, flush=True)
        
        if ct == 'numericType':
            try:
                resultN = float(result)
            except:
                resultN = float(re.findall(r"[+-]? *(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", result)[0])
            rawResult.append(resultN)
            resultS += str(resultN) + ' ' + un + ' '
            if resultN <= cr[1] and resultN >= cr[0]:
                conclusion *= 1
            else:
                conclusion *= 0
        else:
            rawResult.append(result)
            resultS += result + ' ' + un + ' '
            if result == cr[0]:
                conclusion *= 1
            elif result == cr[1]:
                conclusion *= 0
            else:
                raise Exception("resultParser() failed, result does not fit any stringCritria")
    if len(resultS) > 0:
        output['result'] = resultS
        output['raw_result'] = rawResult
    if conclusion == 1:
        output['conclusion'] = 'PASS'
    elif conclusion == 0:
        output['conclusion'] = 'FAILED'
    return output


'''
def linpackParser(contents):
    keywords = ['T/V','Time','Gflops']
    line_numbers = []
    results = []
    contents = contents.split('\n')
    for i, content in enumerate(contents):
        if all([x in content for x in keywords]):
            line_numbers.append(i+2)
    for i in line_numbers:
        results.append(float(contents[i].split()[-1]))
    cpuSpeed = str(round(sum(results)/len(results),2))
    return('CPU SPD: ' + cpuSpeed + 'Gflops')

def stressappParser(contents):
    keywords = ['Stats','Memory Copy','at']
    line_numbers = []
    contents = contents.split('\n')
    for i, content in enumerate(contents):
        if all([x in content for x in keywords]):
            line_numbers.append(i)
    if len(line_numbers) != 1:
        return('N/A')
    MS = contents[line_numbers[0]].split()[-1]
    DC = contents[line_numbers[0]+3].split()[-1]
    ID = contents[line_numbers[0]+4].split()[-1]
    return('MS: ' + MS + '; ' + 'DC: ' + DC + '; ' + 'ID: ' + ID + ';' )

def stressngParser(contents):
    keywords = ['real time','usr time','sys time','bogo ops/s']
    line_numbers = []
    contents = contents.split('\n')
    for i, content in enumerate(contents):
        if all([x in content for x in keywords]):
            line_numbers.append(i+2)
    if len(line_numbers) != 1:
        return('N/A')
    return('bogo: ' + contents[line_numbers[0]].split()[-2] + 'ops/s')
'''

'''
try:
    inputData = parseInput(sys.argv[1])
    print('Config parsed successfully!')
    # input parameters:
    category = inputData['category']
    bmName = inputData['exe']
    config = inputData['config']
    outpath = inputData['log']
    walltime = inputData['walltime']
    # run benchmark
    print('Start ' + category + ' : ' + bmName + ' ' + config)
    logStr = runBenchmark(bmName,config,walltime)
    # generate output
    print('Generating output into path: ' + outpath + '....')
    generateOutput(logStr,outpath)
    print('Done')

except Exception as e:
    print("main() failed")
    print("Error msg:\n{0}".format(e))
'''