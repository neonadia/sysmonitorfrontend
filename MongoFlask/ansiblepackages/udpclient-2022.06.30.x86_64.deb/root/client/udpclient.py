#!/bin/python3

import socket
import threading
import os
import sys
import datetime
import json
import time
from subprocess import Popen, PIPE
from udpParser import parseInput, runBenchmark, runCommand, generateOutput, resultParser, removeOutput
from random import randint
from pymongo import MongoClient
from glob import glob

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

def get_mac(ip):
    cmd = 'ls -1 /sys/class/net | head'
    result = os.popen(cmd).read()
    res = ''
    head_list = result.split()
    for head in head_list:
        if head != 'lo':
            cmd = "ifconfig | grep -A 5 " + head + " | grep inet | grep -v inet6 | awk '{print $2}'"
            ip_temp = os.popen(cmd).read()
            ip_temp = ip_temp.strip()
            if ip_temp != '' and ip_temp == ip:
                cmd = 'cat /sys/class/net/' + head + '/address'
                res = os.popen(cmd).read().strip()

    return res

serverhost = sys.argv[1].split(":")[0]
mongoport = int(sys.argv[1].split(":")[1])
buffsize = 1024
log_file = 'log.json'

'''
def get_self_ip():
    s = socket(AF_INET, SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP
'''

client = MongoClient(serverhost, mongoport)
db = client.udp_config
collection = db.client_config # collection to get udp server port mapping
local_ip = get_ip()
local_mac = get_mac(local_ip).lower().replace('-','').replace(':','')
port = -1
result_port = -1
print("Waiting for assigning udp server port....")
while port == -1 or result_port == -1:
    try:
        port = list(collection.find({"mac":local_mac},{"port":1,"_id":0}))[0]['port']
        result_port = list(collection.find({"mac":local_mac},{"resultport":1,"_id":0}))[0]['resultport']
    except:
        port = -1
        result_port = -1
    time.sleep(1)
print("Server port is " + str(port))
addr = (serverhost, port)

udp_collection = MongoClient(serverhost, result_port).redfish.udp  # collection to insert benchmark results
cmd_collection = MongoClient(serverhost, result_port).redfish.cmd

class Listener(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self)
        self.PORT = port
        self.IP = ''
        self.ADDR = (self.IP, self.PORT)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(self.ADDR)
        self.thStop = False

    def __del__(self):
        self.sock.close()

    @staticmethod
    def load_json_file(filename):
        try:
            with open(filename, 'r') as file:
                data_json = json.load(file)
            file.close()
            return data_json
        except Exception as e:
            print("load_json_file() failed")
            print("Error msg:\n{0}".format(e))
            print('Created new file: ' + filename)
            return None

    @staticmethod
    def write_json_file(filename, data_str):
        try:
            with open(filename, 'w') as file:
                json.dump(data_str, file, indent=4)
            file.close()
        except Exception as e:
            print("write_json_file() failed")
            print("Error msg:\n{0}".format(e))

    def write_log(self, server_ip, f_type, data):

        data_str = {
            server_ip: {
                'log': [
                    {
                        'time': str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                        'type': f_type,
                        'data': data
                    }
                ]
            }
        }
        # open json file and get data_str
        load_str = self.load_json_file(log_file)
        if load_str and load_str.__contains__(server_ip):
                load_str[server_ip]['log'].append(data_str[server_ip]['log'][0])
        else:
            load_str = data_str

        # write json file
        self.write_json_file(log_file, load_str)

    def write_file(self, filename):
        filename = filename.split('/')[-1]
        print('******Receiving ' + filename + ' ******')
        f = open(filename, 'w')
        data, cur_addr = self.sock.recvfrom(buffsize)
        data = data.decode(encoding='utf-8')
        try:
            while data:
                f.write(data)
                self.sock.settimeout(2)
                data, cur_addr = self.sock.recvfrom(buffsize)
                data = data.decode(encoding='utf-8')
        except socket.timeout:
            print("******Done!******")
            f.close()
            self.sock.settimeout(None)

    def run(self):
        print('Listener >>> Waiting for message...')
        while not self.thStop:
            (data, (curIP, curPort)) = self.sock.recvfrom(buffsize)
            data = data.decode(encoding='utf-8')
            header = data.split()
            print('DATA: ' + data)
            if header[0] == 'filename':
                self.write_log(str(curIP), 'file', header[1])
                self.write_file(header[1])
            else:
                print('Listener: ' + str(curIP) + ' >>> ' + data)
                self.write_log(str(curIP), 'msg', data)
            print('Listener >>> Waiting for message...')
            print('Sender >>> msg=m file=f: ')

    def stop(self):
        self.thStop = True


class Sender(threading.Thread):

    def __init__(self, flag_type, ip_mac, data):
        threading.Thread.__init__(self)
        self.PORT = port
        self.ADDR = addr
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.flag = flag_type
        self.ip_mac = ip_mac
        self.data = data
        self.thStop = False

    def __del__(self):
        self.sock.close()

    def send_msg(self, msg):
        print("Sender >>> Send " + self.flag + ' ' + msg + " To " + str(serverhost))
        msg = self.flag + ' ' + self.ip_mac + ' | ' + msg
        msg = msg.encode(encoding='utf-8')
        self.sock.sendto(msg, self.ADDR)

    def send_file(self, filename):
        f = self.open_file(filename)
        if f:
            info = os.stat(filename)
            size = info.st_size
            print("Sender >>> Send " + filename + " To " + str(serverhost))
            filename = 'f ' + self.ip_mac + ' | ' + filename
            self.sock.sendto(filename.encode(encoding='utf-8'), self.ADDR)
            data = f.read(buffsize)
            count = buffsize
            while data:
                if self.sock.sendto(data, self.ADDR):
                    print('Sending...(' + str(count) + '/' + str(size) + ')')
                    data = f.read(buffsize)
                    count += buffsize
                    if count > size:
                        count = size
            print('******Done!******')
        else:
            print('Cannot find the file! ')
        f.close()

    @staticmethod
    def open_file(msg):
        try:
            f = open(msg, 'rb')
            return f
        except Exception as e:
            print("open_file() failed")
            print("Error msg:\n{0}".format(e))
            return None


    def run(self):
        if self.flag == 'f':
            self.send_file(self.data)
        else:
            self.send_msg(self.data)

    def stop(self):
        self.thStop = True


class SenderMain(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self)
        self.flag = ''
        self.data = ''
        self.id = ''
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.thStop = False

    def __del__(self):
        self.stop()
    
    @staticmethod
    def load_json_file(filename):
        try:
            with open(filename, 'r') as file:
                data_json = json.load(file)
            file.close()
            return data_json
        except Exception as e:
            print("load_json_file() failed")
            print("Error msg:\n{0}".format(e))
            print('Created new file: ' + filename)
            return None

    @staticmethod
    def write_json_file(filename, data_str):
        try:
            with open(filename, 'w') as file:
                json.dump(data_str, file, indent=4)
            file.close()
        except Exception as e:
            print("write_json_file() failed")
            print("Error msg:\n{0}".format(e))
    
    def write_log(self, server_ip, f_type, data):

        data_str = {
            server_ip: {
                'log': [
                    {
                        'time': str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                        'type': f_type,
                        'data': data
                    }
                ]
            }
        }
        # open json file and get data_str
        load_str = self.load_json_file(log_file)
        if load_str and load_str.__contains__(server_ip):
                load_str[server_ip]['log'].append(data_str[server_ip]['log'][0])
        else:
            load_str = data_str

        # write json file
        self.write_json_file(log_file, load_str)
    
    def check_log(self,key):
        load_str = self.load_json_file(log_file)
        if load_str and load_str.__contains__(serverhost):
            try:
                last_entry =  load_str[serverhost]['log'][-1]
                return(last_entry[key].split('/')[-1])                
            except Exception as e:
                print("Error msg:\n{0}".format(e))
         
    def run(self):
        print('Server: ' + str(serverhost))

        # get ip and MAC Address
        ip = get_ip()
        mac = get_mac(ip)
        self.id = ip + ',' + mac
        self.flag = 'h'
        sen = Sender(self.flag, self.id, 'ONLINE')
        sen.start()
        sen.stop()
        time.sleep(5)
        self.write_log(serverhost,"msg","initialize")
        while not self.thStop:
            try:
                if self.check_log('type') == 'msg' and self.check_log('data') == 'request_h':
                    self.id = ip + ',' + mac
                    self.flag = 'h'
                    sen = Sender(self.flag, self.id, 'ONLINE')
                    sen.start()
                    sen.stop()
                    time.sleep(5)
                    self.write_log(serverhost,"msg","initialize")
                elif self.check_log('type') == 'msg'and self.check_log('data') != 'request_h':
                    #change flag to 'm' to send success message to server
                    self.flag = 'm'
                    self.data = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ': OK!' 
                    sen = Sender(self.flag, self.id, self.data)
                    sen.start()
                    self.write_log(serverhost,'send confirm',self.data)
                elif self.check_log('type') == 'file':
                    if 'udpinput.json' in self.check_log('data'):
                        self.flag = 'm'
                        time.sleep(3) # flag arrive faster than file
                        try:
                            print('Parse input data ' + self.check_log('data'))
                            inputData = parseInput(self.check_log('data'))
                            if inputData != 1 and inputData != 2:
                                print('Config parsed successfully!')
                            else:
                                print('Config parsed failed!')
                            # input parameters:
                            rackid = self.check_log('data').replace('udpinput.json','')
                            category = inputData['category']
                            bmName = inputData['exe']
                            prefix = inputData['prefix']
                            config = inputData['config']
                            walltime = inputData['walltime']
                            if inputData['selfLog'] == 1:
                                print('Benchmark has selflog file, need to clean previous logs!')
                                removeOutput(inputData['selfLogPath'])
                            # for log parser and criteria
                            '''
                            keywords = inputData['keywords']
                            addRow = inputData['addRow']
                            dfs = inputData['dfs']
                            index = inputData['index']
                            criteriaType = inputData['criteriaType']
                            criteria = inputData['criteria']
                            '''
                            
                            print('Start ' + category + ' : ' + prefix + ' ' + bmName + ' ' + config)
                            start_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            self.data = start_date + ': ' + bmName + ' START!'
                            # send msg : running
                            sen = Sender(self.flag, self.id, self.data)
                            sen.start()
                            self.write_log(serverhost,'send confirm',self.data)
                            # stop sen
                            sen.stop()
                            # run benchmark and generate output
                            if category == "benchmark":
                                logStr = runBenchmark(bmName,prefix,config,walltime)
                            else:
                                logStr = runCommand(bmName,walltime) # bmName is command
                            if inputData['selfLog'] == 0:
                                outpath = inputData['log'] + '-' + rackid + '-' + ip + '.log'
                                print('Generating output into path: ' + outpath + '....')
                                generateOutput(logStr,outpath)
                            else:
                                outpath = []
                                for file in glob('./' + inputData['selfLogPath']):
                                    print("Found " + file)
                                    outpath.append(file)
                                if len(outpath) != 1:
                                    raise Exception("Found " + str(len(outpath)) + " output files")
                                outpath = outpath[0]                                
                            # send output file
                            #print('Waiting for log file: ' + outpath + '....')
                            #while fileEmplty(outputpath):
                            #    time.sleep(1)
                            print('Fetching log file content....')
                            with open(outpath, 'r') as logfile:
                                cur_content = logfile.read()
                            print(cur_content)
                            
                            # parse results
                            conclusionAndResult = {'result':'Disabled','conclusion':'Disabled'}
                            if inputData['parseResultLog'] == 1:
                                conclusionAndResult = resultParser(cur_content, inputData['keywords'], inputData['addRow'], \
                                                                inputData['dfs'], inputData['index'], inputData['unit'],\
                                                                inputData['criteriaType'], inputData['criteria'])
                                print('Result parsed done!')   
                                                      
                            file_data = {\
                            'os_ip':ip,\
                            'mac':mac,\
                            'file_name':outpath,\
                            'start_date':start_date,\
                            'done_date':datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),\
                            'content':cur_content,\
                            'result':conclusionAndResult['result'],\
                            'conclusion':conclusionAndResult['conclusion'],\
                            'category':category,\
                            'config':config,\
                            'cmd':prefix + " " + bmName + " " + config,\
                            'benchmark':inputData['log'],\
                            'unit':['N/A'],\
                            'result_name':['N/A'],\
                            'raw_result':['N/A'],\
                            'star':-1}
                            
                            print(file_data, flush=True)
                            
                            if inputData['parseResultLog'] == 1 and category == "benchmark":
                                file_data['unit'] = inputData['unit']
                                file_data['raw_result'] = conclusionAndResult['raw_result']
                                file_data['result_name'] = inputData['resultName']
                                                        
                            print('Fetch done')
                            print('Insert result into database...')
                            # save outpath into mongodb
                            try:
                                if category == "benchmark":
                                    udp_collection.insert_one(file_data)
                                else:
                                    cmd_collection.insert_one(file_data)
                            except Exception as e:
                                print("Log file insert failed")
                                print("Error msg:\n{0}".format(e))
                            self.data = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ': ' + bmName + ' DONE!'
                        except Exception as e:
                            self.data = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ': ' + e
                        sen = Sender(self.flag, self.id, self.data)
                        sen.start()
                        self.write_log(serverhost,'send confirm',self.data)                        
                time.sleep(1)
            except Exception as e:
                print("Error msg:\n{0}".format(e))
    
    def stop(self):
        self.thStop = True



def main():
    try:
        lis = Listener()
        lis.start()
        sen = SenderMain()
        sen.start()
    except Exception as e:
        print("main() failed")
        print("Error msg:\n{0}".format(e))


if __name__ == '__main__':
    main()
